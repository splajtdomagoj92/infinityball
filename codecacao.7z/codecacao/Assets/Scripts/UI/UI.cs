﻿using UnityEngine;

/// <summary>
/// Every UI class is derived from this class.
/// It contains references to all the required managers for UIs to use.
/// </summary>
public class UI : MonoBehaviour {

    protected GameplayManager gameplayManager;
    protected SaveManager saveManager;
    protected ScoreManager scoreManager;

    private void Awake()
    {
        SetupOnClick();
    }

	public virtual void SetupOnClick()
    {
        gameplayManager = GameplayManager.Instance;
        saveManager = SaveManager.Instance;
        scoreManager = ScoreManager.Instance;
    }
}
