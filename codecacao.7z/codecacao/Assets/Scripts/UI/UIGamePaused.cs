﻿using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// script for the UI when the game is paused
/// </summary>
public class UIGamePaused : UI {

    [SerializeField]
    private Button mainMenuButton;

    [SerializeField]
    private Button restartButton;
    [SerializeField]

    private Button resumeButton;

    public override void SetupOnClick()
    {
        base.SetupOnClick();
        mainMenuButton.onClick.AddListener(gameplayManager.OpenMainMenu);
        restartButton.onClick.AddListener(gameplayManager.RestartGame);
        resumeButton.onClick.AddListener(gameplayManager.PauseGame);
    }


}
