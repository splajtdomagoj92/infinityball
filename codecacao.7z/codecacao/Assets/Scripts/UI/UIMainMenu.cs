﻿using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

/// <summary>
/// Main menu UI script
/// </summary>
public class UIMainMenu : UI
{
    public Button buttonStartGame;
    public Button buttonExit;

    [Header("Game level scene")]
    public string gameLevel;

    public override void SetupOnClick()
    {
        base.SetupOnClick();

        buttonStartGame.onClick.AddListener(delegate { SceneManager.LoadScene(gameLevel); });
        buttonExit.onClick.AddListener(delegate { Application.Quit(); });
    }

}
