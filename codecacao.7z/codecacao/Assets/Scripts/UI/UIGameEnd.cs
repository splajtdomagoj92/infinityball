﻿using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// This UI gets activated when the player dies.
/// </summary>
public class UIGameEnd : UI {

    [SerializeField]
    private Button mainMenuButton;

    [SerializeField]
    private Button restartButton;

    public Text highscoreText;
    public Text scoreText;

    [Header("Prefix in front of actual score number. Example -> Score: 150")]
    public string textScorePrefix;

    [Header("Prefix in front of actual score number. Example -> Highscore: 150")]
    public string highscoreTextScorePrefix;

    public override void SetupOnClick()
    {
        base.SetupOnClick();
        mainMenuButton.onClick.AddListener(gameplayManager.OpenMainMenu);
        restartButton.onClick.AddListener(gameplayManager.RestartGame);
    }

    /// <summary>
    /// When player "dies" this gets activated
    /// </summary>
    private void OnEnable()
    {
        saveManager.SaveHighScore(scoreManager.GetScore());
        highscoreText.text = highscoreTextScorePrefix + saveManager.LoadHighScore().ToString();
        scoreText.text = textScorePrefix + scoreManager.GetScore().ToString();
    }
}
