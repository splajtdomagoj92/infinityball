﻿using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// Gameplay UI script
/// </summary>
public class UIGameplay : UI {

    [SerializeField]
    private Button pauseButton;

    public Text textScore;
    public Text textHighScore;

    [Header("Prefix in fron of actual score number. Example -> Score: 150")]
    public string textScorePrefix;
    public string textHighScorePrefix;

    public override void SetupOnClick()
    {
        base.SetupOnClick();
        pauseButton.onClick.AddListener(gameplayManager.PauseGame);
    }

    private void Start()
    {
        textScore.text = textScorePrefix + 0;
        textHighScore.text = textHighScorePrefix + saveManager.LoadHighScore();
    }

    /// <summary>
    /// Set score on the screen.
    /// </summary>
    /// <param name="score"></param>
    public void SetScore(int score)
    {
        textScore.text = textScorePrefix + score.ToString();
    }
}
