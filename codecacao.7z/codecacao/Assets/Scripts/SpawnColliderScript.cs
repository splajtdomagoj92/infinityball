﻿using UnityEngine;

/// <summary>
/// This collider is used to hit the game area when the ball is at that area "exit" position and the area teleports to it's next position. This is done so we can recycle the game area.
/// </summary>
public class SpawnColliderScript : MonoBehaviour {

    [SerializeField]
    private Transform ball;

    [Header("Collider distance from the ball")]
    [SerializeField]
    private float colliderOffsetZ;

    private void Update()
    {
        transform.position = new Vector3(0, 0, ball.transform.position.z + colliderOffsetZ);
    }
}
