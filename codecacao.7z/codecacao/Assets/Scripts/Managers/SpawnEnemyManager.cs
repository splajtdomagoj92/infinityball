﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Spawn enemy obstacles
/// </summary>
public class SpawnEnemyManager : MonoBehaviour {

    [Header("Minimum distance from the ball where obstacles spawn")]
    [SerializeField]
    private float minDistanceZ;

    [SerializeField]
    private int obstaclesAmount;

    [SerializeField]
    private string obstaclesPrefabPath;

    private List<GameObject> obstacleList = new List<GameObject>();

    [Header("How often will the obstacle be spawned")]
    [SerializeField]
    private float spawnTime;

    [SerializeField]
    private Transform ball;

    private Coroutine spawnCoroutine;

    private void Start()
    {
        CreateObstacles();
        spawnCoroutine = StartCoroutine(SpawnObstacleCoroutine());
    }

    /// <summary>
    /// Create an object pool
    /// </summary>
    private void CreateObstacles()
    {
        for (int i = 0; i < obstaclesAmount; i++)
        {
            GameObject go = Instantiate(Resources.Load<GameObject>(obstaclesPrefabPath));
            go.SetActive(false);
            obstacleList.Add(go);
        }
    }

    private IEnumerator SpawnObstacleCoroutine()
    {
        yield return new WaitForSeconds(spawnTime);
        SpawnObstacle();
    }

    private void SpawnObstacle()
    {
        GameObject go = GetObstacle();
        go.SetActive(true);
        go.transform.position = new Vector3(ball.transform.position.x, ball.transform.position.y, ball.transform.position.z + minDistanceZ);

        spawnCoroutine = null;
        spawnCoroutine = StartCoroutine(SpawnObstacleCoroutine());
    }

    /// <summary>
    /// Get an inactive obstacle, if there isn't one, we create a new one
    /// </summary>
    /// <returns></returns>
    public GameObject GetObstacle()
    {
        int obstacleListCount = obstacleList.Count;
        for (int i = 0; i < obstacleListCount; i++)
        {
            if (!obstacleList[i].activeSelf)
                return obstacleList[i];
        }

        GameObject go = Instantiate(Resources.Load<GameObject>(obstaclesPrefabPath));
        obstacleList.Add(go);
        return go;
    }

}
