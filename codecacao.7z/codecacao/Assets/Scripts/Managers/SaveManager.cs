﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Saves scores in player prefs. Using player prefs because of their simplicity.
/// </summary>
public class SaveManager : Singleton<SaveManager> {

    [SerializeField]
    private string prefsHighScore;

#region Scoring

    public void SaveHighScore(int score)
    {
        SafetyCheck(prefsHighScore);

        if (!NewScoreBetter(prefsHighScore, score))
            return;

        PlayerPrefs.SetString(prefsHighScore, score.ToString());
        PlayerPrefs.Save();
    }

    public int LoadHighScore()
    {
        SafetyCheck(prefsHighScore);
        return int.Parse(PlayerPrefs.GetString(prefsHighScore));
    }


#endregion


    /// <summary>
    /// Check if the player pref exists. If it doesn't, create one.
    /// </summary>
    /// <param name="playerPref">Player pref key</param>
    private void SafetyCheck(string playerPref)
    {
        if (PlayerPrefs.HasKey(playerPref))
            return;

        PlayerPrefs.SetString(playerPref, "0");

        PlayerPrefs.Save();
    }


    /// <summary>
    /// Check if the previously set score was better
    /// </summary>
    /// <param name="playerPref"></param>
    /// <param name="newScore"></param>
    /// <returns></returns>
    private bool NewScoreBetter(string playerPref, int newScore)
    {
        int previousScore = int.Parse(PlayerPrefs.GetString(playerPref));
        if (newScore <= previousScore)
            return false;

        return true;
    }
}
