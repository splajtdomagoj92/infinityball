﻿using System.Collections;
using UnityEngine;

public class CameraManager : Singleton<CameraManager> {

    [SerializeField]
    private Transform ball;

    [Header("Camera offset from the ball when the ball hits an obstacle")]
    public Vector3 deathCameraPosition;
    public float moveToDeathPositionSpeed;
    private bool deadPosition;

    [SerializeField]
    private Transform mainCamera;

    [Header("Camera distance from the ball")]
    [SerializeField]
    private Vector3 cameraOffset;

    private void Update()
    {
        CameraFollowPlayer();
    }

    /// <summary>
    /// Camera follows the ball
    /// </summary>
    private void CameraFollowPlayer()
    {
        mainCamera.transform.position = new Vector3(ball.transform.position.x + cameraOffset.x, ball.transform.position.y + cameraOffset.y, ball.transform.position.z + cameraOffset.z);
    }

    public void ActivateMoveToDeathCameraPosition()
    {
        deadPosition = true;
        StartCoroutine(MoveToPosition());
    }

    public IEnumerator MoveToPosition()
    {
        var t = 0f;
        while (t < 1)
        {
            t += Time.deltaTime / moveToDeathPositionSpeed;
            Vector3 movePosition = new Vector3(ball.position.x + deathCameraPosition.x, ball.position.y + deathCameraPosition.y, ball.position.z + deathCameraPosition.z);
            mainCamera.position = Vector3.Lerp(mainCamera.position, movePosition, t);
            mainCamera.LookAt(ball);
            yield return null;
        }
    }
}
