﻿using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

/// <summary>
/// Main manager in the game.
/// Controls pausing, ending the game.
/// </summary>
public class GameplayManager : Singleton<GameplayManager> {

    private CameraManager cameraManager;

    [Header("Script attached to the ball")]
    [SerializeField]
    private BallScript ballScript;

    [Header("This level scene name. Used to restart the game")]
    public string levelName;

    [Header("Main menu scene name. Used to restart the game")]
    public string mainMenuName;

    #region UI

    [SerializeField]
    private GameObject uiGameplay;
    [SerializeField]
    private GameObject uiGameEnd;
    [SerializeField]
    private GameObject uiGamePaused;

    #endregion UI

    [Header("How much time will pass before the End Game UI is shown")]
    public float gameEndWaitTime;
    private Coroutine coroutineEndGame;
    

    private void Awake()
    {
        cameraManager = CameraManager.Instance;
    }

    private void PauseTime()
    {
        if (Time.timeScale == 1)
            Time.timeScale = 0;
        else
            Time.timeScale = 1;
    }
    
    /// <summary>
    /// Pause and unpause game
    /// </summary>
    public void PauseGame()
    {
        PauseTime();

        if(uiGameplay.activeSelf)
        {
            uiGameplay.SetActive(false);
            uiGamePaused.SetActive(true);
        }
        else
        {
            uiGameplay.SetActive(true);
            uiGamePaused.SetActive(false);
        }
    }

    public void RestartGame()
    {
        PauseTime();
        SceneManager.LoadScene(levelName);
    }

    public void OpenMainMenu()
    {
        PauseTime();
        SceneManager.LoadScene(mainMenuName);
    }

    /// <summary>
    /// Called when the ball hits an obstacle
    /// </summary>
    public void GameOver()
    {
        if (ballScript.IsDead)
            return;

        ballScript.IsDead = true;
        uiGameplay.SetActive(false);
        cameraManager.ActivateMoveToDeathCameraPosition();

        StartCoroutine(CoroutineEndGame());
    }

    private IEnumerator CoroutineEndGame()
    {
        yield return new WaitForSeconds(gameEndWaitTime);
        uiGameplay.SetActive(false);
        uiGameEnd.SetActive(true);
        PauseTime();
    }


}
