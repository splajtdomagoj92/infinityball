﻿using UnityEngine;
using UnityEngine.UI;


public class MainMenuManager : Singleton<MainMenuManager>
{
    private SaveManager saveManager;
    private GameplayManager gameplayManager;

#region Panels

    [SerializeField]
    private GameObject panelMainMenu;

    [SerializeField]
    private GameObject panelCreditsMenu;

    [SerializeField]
    private GameObject panelSettingsMenu;

    [SerializeField]
    private GameObject panelLeaderboardsMenu;

    [SerializeField]
    private GameObject panelStatisticsMenu;

    [SerializeField]
    private GameObject panelUnlocksMenu;

    [SerializeField]
    private GameObject panelGameplay;

    [SerializeField]
    private GameObject panelEndGame;

    private GameObject panelCurrent;

#endregion

#region Backgrounds

    [SerializeField]
    private Image[] backgrounds;
    [SerializeField]
    private Image[] backgroundsEdges;
    [SerializeField]
    private Image backgroundQuestion;

    [SerializeField]
    private string backgroundPath;
    [SerializeField]
    private string backgroundBlackPath;

    [SerializeField]
    private string backgroundWidescreenPath;
    [SerializeField]
    private string backgroundBlackWidescreenPath;

    [SerializeField]
    private string backgroundEdgeWidescreenPath;

    [SerializeField]
    private string backgroundQuestionPath;
    [SerializeField]
    private string backgroundQuestionAlternatePath;

#endregion


}
