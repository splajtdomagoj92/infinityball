﻿using UnityEngine;

/// <summary>
/// Manages the scoring system.
/// </summary>
public class ScoreManager : Singleton<ScoreManager> {

    [Header("Points awarded to the player when he/she avoids the obstacle")]
    [SerializeField]
    private int scoreIncrement;

    /// <summary>
    /// Current score
    /// </summary>
    private int score;

    [SerializeField]
    private UIGameplay uiGameplay;

    public void UpdateScore()
    {
        score += scoreIncrement;
        uiGameplay.SetScore(score);
    }

    /// <summary>
    /// Returns the current score
    /// </summary>
    /// <returns></returns>
    public int GetScore()
    {
        return score;
    }

}
