﻿using UnityEngine;

public class BallScript : MonoBehaviour {

    /// <summary>
    /// Determines whether the plaer is alive or dead
    /// </summary>
    public bool IsDead
    {
        get; set;
    }

    [SerializeField]
    private float ballSpeed;

    [Header("Used in editor with keyboard input")]
    [SerializeField]
    private float ballTurnSpeed;
    [Header("Used for Android build with accelerometer input")]
    [SerializeField]
    private float ballTurnSpeedAccelerometer;

    /// <summary>
    /// This game objects rigidbody
    /// </summary>
    private Rigidbody body;

    private void Start()
    {
        body = GetComponent<Rigidbody>();
    }

    private void Update()
    {
        // if ball is dead, controls get disabled
        if (IsDead)
            return;

        body.MovePosition(body.position + Vector3.forward * ballSpeed * Time.deltaTime);
        AndroidMove();
        EditorMove();
    }

    /// <summary>
    /// Use only for editor
    /// This is used in update because we want to be able to register key input iimmediately as it happens
    /// I'm using ForceMode.VelocityChange as it creates a nice realistic moving to a side
    /// </summary>
    private void EditorMove()
    {
        if (!Application.isEditor)
            return;

        if (Input.GetKey(KeyCode.A))
            body.AddForce(Vector3.left * ballTurnSpeed * Time.deltaTime, ForceMode.VelocityChange);

        if (Input.GetKey(KeyCode.D))
            body.AddForce(Vector3.right * ballTurnSpeed * Time.deltaTime, ForceMode.VelocityChange);
    }

    /// <summary>
    /// Android controls
    /// </summary>
    private void AndroidMove()
    {
        if (Application.platform != RuntimePlatform.Android )
            return;

        Vector3 accelerometer = Input.acceleration;
        body.AddForce(accelerometer.x * ballTurnSpeedAccelerometer * Time.deltaTime, 0, 0, ForceMode.VelocityChange);
    }
}
