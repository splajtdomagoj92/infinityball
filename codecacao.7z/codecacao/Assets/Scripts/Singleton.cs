﻿using UnityEngine;

/// <summary>
/// Shortens the code for every class we want to have a single instance of.
/// Every class that uses Singleton can be accessed through the public Instance field.
/// </summary>
/// <typeparam name="T"></typeparam>
public class Singleton<T> : MonoBehaviour where T : MonoBehaviour {

    private static T instance;
    public static T Instance
    {
        get
        {
            if (instance == null)
                instance = FindObjectOfType<T>();

            return instance;
        }
    }
}
