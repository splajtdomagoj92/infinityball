﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AreaColliderScript : MonoBehaviour {

    [SerializeField]
    private Transform parentRoadArea;

    [SerializeField]
    private Transform nextPosition;

    [SerializeField]
    private string ballSpawnColliderTag;

    /// <summary>
    /// If the ball hits this collider, this game area gets teleported to the next position, this way we're just recycling the game area
    /// </summary>
    /// <param name="col"></param>
    private void OnTriggerEnter(Collider col)
    {
        if(col.tag == ballSpawnColliderTag)
            parentRoadArea.position = nextPosition.position;
    }

}
