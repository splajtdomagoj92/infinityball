﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObstacleScript : MonoBehaviour {

    private GameplayManager gameplayManager;
    private ScoreManager scoreManager;

    [Header("Force with which the ball will get bounced of the obstacle it hits")]
    public float reflectForce;

    [SerializeField]
    private float ballSpeed;
    private Rigidbody body;

    [SerializeField]
    private string ballSpawnColliderTag;

    [SerializeField]
    private string ballTag;

    /// <summary>
    /// Create caches for later use
    /// </summary>
    private void Awake()
    {
        gameplayManager = GameplayManager.Instance;
        scoreManager = ScoreManager.Instance;
        body = GetComponent<Rigidbody>();
    }

    /// <summary>
    /// Called when the obstacle hits the player ball
    /// </summary>
    /// <param name="col"></param>
    private void OnCollisionEnter(Collision col)
    {
        if (col.gameObject.tag != ballTag)
            return;

        /// for this part i followed https://www.youtube.com/watch?v=bsLFIPoBPEQ
        /// i used this because the ball gets properly bounced of the collided obstacle
        Vector3 ballVector = transform.position - col.transform.position;
        Vector3 planeTangent = Vector3.Cross(ballVector, Vector3.back);
        Vector3 planeNormal = Vector3.Cross(planeTangent, ballVector);
        Vector3 reflectedVector = Vector3.Reflect(Vector3.back, planeNormal).normalized;

        col.gameObject.GetComponent<Rigidbody>().velocity = reflectedVector * reflectForce;
        gameplayManager.GameOver();
    }

    /// <summary>
    /// This will make this obstacle available to the spawn pool in spawnobstaclemanager if the obstacle hits the collider behind the ball
    /// </summary>
    /// <param name="col"></param>
    private void OnTriggerEnter(Collider col)
    {
        if (col.gameObject.tag == ballSpawnColliderTag)
        {
            gameObject.SetActive(false);
            scoreManager.UpdateScore();
        }
    }

    private void Update()
    {
        body.MovePosition(body.position + Vector3.back * ballSpeed * Time.deltaTime);
    }
}
